package webb;
import static org.junit.Assert.*;

import org.junit.Test;
public class AssertTest {
	
	@Test
	public void test(){
	
	
	String str1="abc";
	String str2="abc";
	int val1=10;
	int val2=11;
	String a[]={"one","two","three"};
	String b[]={"one","two","three"};
	
	assertEquals(str1,str2);
	
	assertTrue(val2>val1);
	
	assertFalse(val1>val2);
	
	assertArrayEquals(a,b);
	
	}
}
/*
 *
 */