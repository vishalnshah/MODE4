package webb;

import org.testng.annotations.Test;

public class JunitPriority {
	@Test(priority=2)
	public void c()
	{
		System.out.println("c");
	}
	@Test(priority=1)
	public void b()
	{
		System.out.println("b");
	}
	@Test(priority=0)
	public static void a()
	{
		System.out.println("a");
	}
}
