package webb;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class InternetExplorer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.ie.driver","D:/IEDriverServer.exe");
		WebDriver d=new InternetExplorerDriver();
		String b="http://www.google.com";
		
		d.get(b);
		
	}

}
