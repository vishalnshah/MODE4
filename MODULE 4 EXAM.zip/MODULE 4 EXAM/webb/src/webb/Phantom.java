package webb;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.*;

public class Phantom {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("phantomjs.binary.path","D:/PINAK/PhantomJS/phantomjs.exe");
		WebDriver d=new PhantomJSDriver();
		String b="http://www.google.com";
		
		d.get(b);
		System.out.println("Page title is:" + d.getTitle());
		d.close();
		
	}

}
