package webb;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Screenshot {

	@Test
	public void takescreenshot() throws Exception
	{
		WebDriver driver;
		driver=new FirefoxDriver();
		driver.get("https://www.opencart.com/");
		this.takeSnapShot(driver,"D://PINAK/test.png");
	}
	public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws IOException {
		// TODO Auto-generated method stub
		TakesScreenshot scrShot=((TakesScreenshot)webdriver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(fileWithPath);
		FileUtils.copyFile(SrcFile,  DestFile);

	}

}
