package webb;

import org.junit.*;


public class JunitTest4 {
	@Test
	public void a3b3()
	{
		System.out.println("c");
	}
	@Test
	public void a2b2()
	{
		System.out.println("b");
	}
	@Test
	public void a1b1()
	{
		System.out.println("a");
	}
}
