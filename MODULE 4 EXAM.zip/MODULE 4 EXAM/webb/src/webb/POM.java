package webb;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import webb.Loginpm;
public class POM {

	WebDriver driver;
	Loginpm objlogin;
	
	@BeforeTest
	public void setup()
	{
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("file:///D:/PINAK/LoginPage.html");
	}
	
	@Test
	public void DoLogin()
	{
		objlogin=new Loginpm();
		objlogin.login(driver);
		objlogin.LoginToShopping("strUserName", "strPassword");

	}
}
