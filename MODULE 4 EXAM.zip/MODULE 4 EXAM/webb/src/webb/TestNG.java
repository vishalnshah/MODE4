package webb;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;

public class TestNG {
	@Test
	public void testCheck()
	{
		String str="Welcome";
		AssertJUnit.assertEquals("Welcome",str);
		
	}
}
