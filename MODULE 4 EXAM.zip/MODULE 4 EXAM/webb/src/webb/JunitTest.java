package webb;

import org.junit.*;

public class JunitTest {

	@Test
	public void initialize()
	{
		System.out.println("Test");
	}
	@Before
	public void myTestMethod()
	{
		System.out.println("Before");
	}
	@After
	public void close()
	{
		System.out.println("After");
	}
}
