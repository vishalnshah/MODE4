package com.lab;

public class StringTooLongException extends Exception {

}
