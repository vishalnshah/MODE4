package webb;

import org.junit.*;


public class JunitTest3 {
	@Test
	public void initialize()
	{
		System.out.println("Test");
	}
	@Before
	public void myTestMethod()
	{
		System.out.println("Before");
	}
	@After
	public void close()
	{
		System.out.println("After");
	}
	@BeforeClass
	public static void beforeClass()
	{
		System.out.println("Before Class");
	}
	@AfterClass
	public static void afterClass()
	{
		System.out.println("After Class");
	}
	@Ignore
	public void ignore()
	{
		System.out.println("Ignore");
	}
}
//order-> @BeforeClass->@Before->@Test->@After->@AfterClass

