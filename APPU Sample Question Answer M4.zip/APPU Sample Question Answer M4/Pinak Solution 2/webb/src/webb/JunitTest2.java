package webb;

import org.junit.*;


public class JunitTest2 {
	@Test
	public void c()
	{
		System.out.println("c");
	}
	@Test
	public void b()
	{
		System.out.println("b");
	}
	@AfterClass
	public static void a()
	{
		System.out.println("a");
	}
}
