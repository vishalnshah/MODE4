package webb;

import org.openqa.selenium.*;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;

public class ImplicitExplicit {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		String baseurl="file:///D:/PINAK/Module%204/mod4/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
		driver.get(baseurl);
		
		WebElement t=driver.findElement(By.id("txtUserName"));
		Thread.sleep(2000);
		t.sendKeys("asd");

	}

}


