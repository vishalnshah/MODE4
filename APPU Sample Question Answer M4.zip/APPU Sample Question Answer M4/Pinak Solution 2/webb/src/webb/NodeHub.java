package webb;


import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class NodeHub {

	WebDriver driver;
	String baseurl,nodeurl;
	@BeforeTest
	public void display() throws MalformedURLException
	{
		baseurl="file:///D:/PINAK/Module%204/mod4/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
		nodeurl="http://10.102.51.41:5666/wd/hub";
		new DesiredCapabilities();
		DesiredCapabilities t = DesiredCapabilities.chrome();
		t.setBrowserName("chrome");
		t.setPlatform(Platform.WINDOWS);
		driver= new RemoteWebDriver(new URL (nodeurl),t);
		
	}
	
	@AfterTest
	public void aftertest()
	{
		//driver.close();
	}
	
	@Test
	public void simpletest()
	{
		driver.get(baseurl);
		//Thread.sleep(1000);
		Assert.assertEquals("Email Registration Form", driver.getTitle());
	}

	}
