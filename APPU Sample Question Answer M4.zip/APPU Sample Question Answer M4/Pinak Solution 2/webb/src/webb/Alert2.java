package webb;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Alert2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new FirefoxDriver();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("history.go(0)");
		
		driver.get("file:///D:/PINAK/Module%204/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/AlertExample.html");
		//sText=js.executeScript("return document.title;").toString();
		//System.out.println(sText);
		
		driver.findElement(By.name("txtName")).sendKeys("Pinak");
	
		driver.findElement(By.name("btnAlert")).click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		js.executeScript("alert('hii')");
	}

}
