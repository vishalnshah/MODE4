package webb;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Loginpm {
	WebDriver driver;
	By username=By.name("userid");
	By password=By.name("psswrd");
	By Loginbtn=By.xpath("/html/body/form/input[3]");
	By Cancelbtn=By.xpath("/html/body/form/input[4]");

	public void login(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void setUserName(String strUserName)
	{
		driver.findElement(username).sendKeys("SeleniumUser");
	}
	
	public void setPassword(String strPassword)
	{
		driver.findElement(password).sendKeys("selenium123");
	}
	public void clickLogin()
	{
		driver.findElement(Loginbtn).click();
	}
	
	public void LoginToShopping(String strUserName,String strPassword)
	{
		this.setUserName(strUserName);
		this.setPassword(strPassword);
		this.clickLogin();
	}
}

